# God-of-the-Gym

    Projeto Integrador (PI)

# O'que é ?

    Aplicação em Desktop em produção

# Qual a ideia do projeto 

    Auxiliar novos emprededores no ramo de academia, 
    dando um controle e gestão de academia mais faceis 
    Contendo : 
        Administração dos funcionarios
        Administração dos alunos 
        Administração dos planos 

        # Com acesso e controle sobre os perfis dos :

                Funcionarios 
                Alunos
                planos

# Integrantes do Projeto 

    Dimitri Schmidt
    Gabriel Mendes Motta 
    Vinícius Nunes Bispo 


package controller;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Optional;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import model.Planos;
import model.PlanosDAO;
import util.Alerta;


public class PerfilPlanoController {
    Stage stage;
    Planos plano;
    PlanosDAO dao = new PlanosDAO();
    
    
    @FXML
    private Button bntAulas;

    @FXML
    private Button btnEditar;

    @FXML
    private Button btnExcluir;

    @FXML
    private Label lbNome;

    @FXML
    private Label lbTipo;

    @FXML
    private Label lbValor;
    
    public void setStage(Stage stage, Planos plano) throws SQLException {
        this.stage = stage;
        this.plano = plano;
        configurarTela();
    }
    
    @FXML
    void voltarPlanos(ActionEvent event) throws SQLException, IOException {
      URL url = new File ("src/main/java/view/planos.fxml").toURI().toURL();
      FXMLLoader loader = new FXMLLoader(url);
      Parent root = loader.load();
      Stage telaPlanos = new Stage();
      PlanosController pc = loader.getController();
      pc.setStage(telaPlanos);
      Scene scene = new Scene(root);
      telaPlanos.setScene(scene);
      telaPlanos.show();
      stage.close();
    }
    
    void configurarTela() {
    lbNome.setText(plano.getNome());
    lbTipo.setText(plano.getTipo());
    lbValor.setText(String.valueOf(plano.getPreco()));
    }
    
    @FXML
    void excluirPlanos(ActionEvent event){
        
    }
}

package controller;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Planos;
import model.PlanosDAO;

public class PlanosController{

    Stage stagePlanos;
    ObservableList<Planos> lista = FXCollections.observableArrayList();

    @FXML
    private Button bntAdicionar;
    
    @FXML
   private Button btnHome;
    
     @FXML
    private TableView<Planos> tabela;

    @FXML
    private TextField tfPesquisa;
    
    public void setStage(Stage stage) throws SQLException{
        this.stagePlanos = stage;
        configurarTabela();
    }
    
    @FXML
    void voltarHome(ActionEvent event) throws IOException{
      URL url = new File ("src/main/java/view/home.fxml").toURI().toURL();
      FXMLLoader loader = new FXMLLoader(url);
      Parent root = loader.load();
      Stage home = new Stage();
      HomeController hc = loader.getController();
      hc.setStage(home);
      Scene scene = new Scene(root);
      home.setScene(scene);
      home.show();
      stagePlanos.close();
    }

    @FXML
    void abrirAddPlano(ActionEvent event) throws IOException {
      URL url = new File ("src/main/java/view/addPlano.fxml").toURI().toURL();
      FXMLLoader loader = new FXMLLoader(url);
      Parent root = loader.load();
      Stage telaAddPlano = new Stage();
      AddPlanoController acc = loader.getController();
      acc.setStage(telaAddPlano);
      Scene scene = new Scene(root);
      telaAddPlano.setScene(scene);
      telaAddPlano.show();
    }
    
    public void configurarTabela() throws SQLException{
        lista.setAll(listarPlanos());
        if (!lista.isEmpty()){
            tabela.getColumns().clear();
            TableColumn<Planos, String> colunaNome = new TableColumn<>("Nome");
            colunaNome.setCellValueFactory(u -> new SimpleStringProperty(u.getValue().getNome()));
            
            TableColumn<Planos, String> colunaTipo = new TableColumn<>("Tipo");
            colunaTipo.setCellValueFactory(u -> new SimpleStringProperty(u.getValue().getTipo()));
            
            TableColumn<Planos, String> colunaValor = new TableColumn<>("Valor");
            colunaValor.setCellValueFactory(u -> new SimpleStringProperty(String.valueOf(u.getValue().getPreco())));
            
            tabela.getColumns().addAll(colunaNome,colunaTipo,colunaValor);
            tabela.getColumns().forEach(e -> {
                e.setPrefWidth(225);
            });
            
            FilteredList<Planos> listaFiltrada = new FilteredList<>(lista, p -> true);
            tfPesquisa.textProperty().addListener((obs, oldVal, newVal) -> {
                listaFiltrada.setPredicate(Plano -> {
                    if (newVal == null || newVal.isEmpty()) {
                        return true;
                    }
                    String filtro = newVal.toLowerCase();
                    String valor = String.valueOf(Plano.getPreco());
                    return Plano.getNome().toLowerCase().contains(filtro)
                            || Plano.getTipo().toLowerCase().contains(filtro)
                            || valor.toLowerCase().contains(filtro);
                });
            });

            SortedList<Planos> listaOrdenada = new SortedList<>(listaFiltrada);
            listaOrdenada.comparatorProperty().bind(tabela.comparatorProperty());
            tabela.setItems(listaOrdenada);
            
            tabela.setRowFactory(e -> { //setRow customiza a linha
                TableRow<Planos> linha = new TableRow<>();
                linha.setOnMouseClicked(event -> {
                    if (!linha.isEmpty() && event.getClickCount() == 2) {
                        Planos planoSelecionado = linha.getItem(); //get item porque a gente setou os item logo acima
                        try {
                            acessarPerfil(planoSelecionado);
                        } catch (IOException | SQLException ex) {
                            Logger.getLogger(ClientsController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                });
                return linha;
            });
        }
        }
    
       
    private ObservableList<Planos> listarPlanos() throws SQLException{
        PlanosDAO dao = new PlanosDAO();
        return dao.selecionarPlanos();
    }

        void acessarPerfil(Planos plano) throws IOException, SQLException {
        URL url = new File("src/main/java/view/perfilPlano.fxml").toURI().toURL();
        FXMLLoader loader = new FXMLLoader(url);
        Parent root = loader.load();
        Stage telaPerfil = new Stage();
        PerfilPlanoController ppc = loader.getController();
        ppc.setStage(telaPerfil, plano);
        Scene scene = new Scene(root);
        telaPerfil.setScene(scene);
        telaPerfil.show();
        stagePlanos.close();
    }
}

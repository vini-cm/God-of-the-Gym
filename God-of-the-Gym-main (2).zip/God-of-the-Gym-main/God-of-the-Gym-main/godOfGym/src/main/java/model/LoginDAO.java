
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class LoginDAO extends genericoDAO{
    public Boolean bancoOnline(){
        Connection conn = conectarConn();
        if (conn != null){
            try {
                conectarConn().close();
            } catch (Exception e) {
            }
            return true;
        } else {
            return false;
        }
    }
    
    public Usuario autenticar(String Nome, String Senha) throws SQLException {
        String sql = "SELECT * from usuario Where Nome = ? and Senha = ?";
        Usuario user = null;
        Connection conn = conectarConn();
        if (conn != null){
            PreparedStatement stmt = conectarConn().prepareStatement(sql);
            stmt.setString(1, Nome);
            stmt.setString(2,Senha);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()){
            user = new Usuario();
            user.setCPF(rs.getInt("CPF"));
            user.setNome(rs.getString("Nome"));
            user.setSobrenome(rs.getString("Sobrenome"));
            user.setDataNascimento(rs.getString("dataNascimento"));
            user.setEmail(rs.getString("Email"));
            user.setSenha(rs.getString("Senha"));
            user.setGenero(rs.getString("genero").charAt(0));
            }
            rs.close();
            stmt.close();
            conectarConn().close();
            return user;
        } else {
            return null;
        }
        
    }
}
